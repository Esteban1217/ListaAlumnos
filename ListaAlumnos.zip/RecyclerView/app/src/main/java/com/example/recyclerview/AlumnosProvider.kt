package com.example.recyclerview

class AlumnosProvider {
    companion object {
        val listaAlumnos = listOf<ListaAlumnos>(
            ListaAlumnos(
                nombre = "Esteban",
                cuenta = "20196756",
                correo = "Ediaz25@ucol.mx",
                imagen = R.drawable.esteban
            ),
            ListaAlumnos(
                nombre = "Omar",
                cuenta = "20195402",
                correo = "OChavez@ucol.mx",
                imagen = R.drawable.chavez
            ),

            ListaAlumnos(
                nombre = "Kevin",
                cuenta = "20194022",
                correo = "KRosales@ucol.mx",
                imagen = R.drawable.kevin
            ),

            ListaAlumnos(
                nombre = "Enrique",
                cuenta = "20194023",
                correo = "Enrique2@ucol.mx",
                imagen = R.drawable.enrique
            )


            )

    }
}
