package com.example.recyclerview

data class ListaAlumnos(
    val nombre: String,
    val cuenta: String,
    val imagen: Int,
    val correo: String
)
