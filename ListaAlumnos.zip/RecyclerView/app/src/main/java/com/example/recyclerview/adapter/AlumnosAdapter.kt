package com.example.recyclerview.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerview.ListaAlumnos
import com.example.recyclerview.R

class AlumnosAdapter(private val listaAlumnos: List<ListaAlumnos>) : RecyclerView.Adapter<AlumnosViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlumnosViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return AlumnosViewHolder(layoutInflater.inflate(R.layout.item_alumnos, parent, false))
    }

    override fun onBindViewHolder(holder: AlumnosViewHolder, position: Int) {
        val item =  listaAlumnos[position]
        holder.render(item)
    }

    override fun getItemCount(): Int {
        return listaAlumnos.size

    }
}




