package com.example.recyclerview.adapter

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.recyclerview.ListaAlumnos
import com.example.recyclerview.R

class AlumnosViewHolder(view:View):RecyclerView.ViewHolder(view) {

    val alumnosName = view.findViewById<TextView>(R.id.tvAlumnosName)
    val alumnosCuenta= view.findViewById<TextView>(R.id.tvAlumnoscuenta)
    val correo = view.findViewById<TextView>(R.id.tvCorreo)
    val imagen = view.findViewById<ImageView>(R.id.tvimagen)



    fun render(alumnoModel: ListaAlumnos) {
        alumnosName.text = alumnoModel.nombre
        alumnosCuenta.text = alumnoModel.cuenta
        correo.text = alumnoModel.correo
        Glide.with(imagen.context).load(alumnoModel.imagen).into(imagen)

    }
}
